import Client.ui.ClientUI;

public class Main {
    public static void main(String[] args) throws Exception {
        ClientUI clientUI = new ClientUI();
    }
}
